#include "hello.h"
#include <stdio.h>

void Hello::Print()
{
  printf("Hello, World!\n");
}
