"""Blackbox tests. """
